/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controlador;

import modelo.Conexion;

public class main {

    
    public static void main(String[] args) {
        
        Aplicacion miAplicacion = new Aplicacion();
        miAplicacion.iniciarSistema();
        
        //Conexión a la base de datos rinber
        
        /*
        Conexion conexionPrueba = new Conexion();
        conexionPrueba.definirUsuarioContra("768478066", "768478066");
        conexionPrueba.Conexion();

*/
    }

}
