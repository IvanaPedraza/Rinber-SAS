package modelo.vo;

public class vendedorActual {
    private Integer venCedula;
    private String perNombre;
    private String perApellido;
    private String corCorreo;
    private Long telNumero;
    private String venTurno;
    private Integer gerenteCedula;

    public Integer getVenCedula() {
        return venCedula;
    }

    public void setVenCedula(Integer venCedula) {
        this.venCedula = venCedula;
    }

    public String getPerNombre() {
        return perNombre;
    }

    public void setPerNombre(String perNombre) {
        this.perNombre = perNombre;
    }

    public String getPerApellido() {
        return perApellido;
    }

    public void setPerApellido(String perApellido) {
        this.perApellido = perApellido;
    }

    public String getCorCorreo() {
        return corCorreo;
    }

    public void setCorCorreo(String corCorreo) {
        this.corCorreo = corCorreo;
    }

    public Long getTelNumero() {
        return telNumero;
    }

    public void setTelNumero(Long telNumero) {
        this.telNumero = telNumero;
    }

    public String getVenTurno() {
        return venTurno;
    }

    public void setVenTurno(String venTurno) {
        this.venTurno = venTurno;
    }

    public Integer getGerenteCedula() {
        return gerenteCedula;
    }

    public void setGerenteCedula(Integer gerenteCedula) {
        this.gerenteCedula = gerenteCedula;
    }
    
    
}
