package modelo.vo;

public class direccionVo {
    
    private String dirDireccion;
    private String dirCiudad;
    private String dirLocalidad;
    private String dirBarrio;

    public String getDirDireccion() {
        return dirDireccion;
    }

    public void setDirDireccion(String dirDireccion) {
        this.dirDireccion = dirDireccion;
    }

    public String getDirCiudad() {
        return dirCiudad;
    }

    public void setDirCiudad(String dirCiudad) {
        this.dirCiudad = dirCiudad;
    }

    public String getDirLocalidad() {
        return dirLocalidad;
    }

    public void setDirLocalidad(String dirLocalidad) {
        this.dirLocalidad = dirLocalidad;
    }

    public String getDirBarrio() {
        return dirBarrio;
    }

    public void setDirBarrio(String dirBarrio) {
        this.dirBarrio = dirBarrio;
    }
    
    
    
}
