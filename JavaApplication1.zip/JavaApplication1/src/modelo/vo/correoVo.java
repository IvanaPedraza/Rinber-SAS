package modelo.vo;

public class correoVo {
    private String corCorreo;
    private String tipo;

    public String getCorCorreo() {
        return corCorreo;
    }

    public void setCorCorreo(String corCorreo) {
        this.corCorreo = corCorreo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    
}
