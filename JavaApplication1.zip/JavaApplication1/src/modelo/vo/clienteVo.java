package modelo.vo;

public class clienteVo {

    private Long numCamara;
    private Long codCertificadoBanc;
    private Long cliNit;
    private String nombreCliente;
    private String rutCliente;
    private int repreCedula;
    private String repreNombre;
    private String repreApellido;
    private String repreCorreo;
    private Long repreTelefono;
    private String direDireccion;
    private String direCiudad;
    private Long teleNumero;
    private String teleTipo;
    private String corrCorreo;
    private String correoTipo;

    public Long getNumCamara() {
        return numCamara;
    }

    public void setNumCamara(Long numCamara) {
        this.numCamara = numCamara;
    }

    public Long getCodCertificadoBanc() {
        return codCertificadoBanc;
    }

    public void setCodCertificadoBanc(Long codCertificadoBanc) {
        this.codCertificadoBanc = codCertificadoBanc;
    }

    public Long getCliNit() {
        return cliNit;
    }

    public void setCliNit(Long cliNit) {
        this.cliNit = cliNit;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getRutCliente() {
        return rutCliente;
    }

    public void setRutCliente(String rutCliente) {
        this.rutCliente = rutCliente;
    }

    public int getRepreCedula() {
        return repreCedula;
    }

    public void setRepreCedula(int repreCedula) {
        this.repreCedula = repreCedula;
    }

    public String getRepreNombre() {
        return repreNombre;
    }

    public void setRepreNombre(String repreNombre) {
        this.repreNombre = repreNombre;
    }

    public String getRepreApellido() {
        return repreApellido;
    }

    public void setRepreApellido(String repreApellido) {
        this.repreApellido = repreApellido;
    }

    public String getRepreCorreo() {
        return repreCorreo;
    }

    public void setRepreCorreo(String repreCorreo) {
        this.repreCorreo = repreCorreo;
    }

    public Long getRepreTelefono() {
        return repreTelefono;
    }

    public void setRepreTelefono(Long repreTelefono) {
        this.repreTelefono = repreTelefono;
    }

    public String getDireDireccion() {
        return direDireccion;
    }

    public void setDireDireccion(String direDireccion) {
        this.direDireccion = direDireccion;
    }

    public String getDireCiudad() {
        return direCiudad;
    }

    public void setDireCiudad(String direCiudad) {
        this.direCiudad = direCiudad;
    }

    public Long getTeleNumero() {
        return teleNumero;
    }

    public void setTeleNumero(Long teleNumero) {
        this.teleNumero = teleNumero;
    }

    public String getTeleTipo() {
        return teleTipo;
    }

    public void setTeleTipo(String teleTipo) {
        this.teleTipo = teleTipo;
    }

    public String getCorrCorreo() {
        return corrCorreo;
    }

    public void setCorrCorreo(String corrCorreo) {
        this.corrCorreo = corrCorreo;
    }

    public String getCorreoTipo() {
        return correoTipo;
    }

    public void setCorreoTipo(String correoTipo) {
        this.correoTipo = correoTipo;
    }
    
    

}
